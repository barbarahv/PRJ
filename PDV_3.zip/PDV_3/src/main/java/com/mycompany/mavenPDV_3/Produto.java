/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenPDV_3;

/**
 *
 * @author barba
 */
public class Produto {
    private int codigo, unidade, qtdEstoque;
    private String nome, ultimaVenda;
    private double preco;
    
    public int getCodigo()                                  { return codigo; }
    public int getUnidade()                                 { return unidade; }
    public int getQtdEstoque()                              { return qtdEstoque; } 
    public String getNome()                                 { return nome; }
    public String getUltimaVenda()                          { return ultimaVenda; }
    public double getPreco()                                { return preco; }
    
    public void setCodigo( int codigo )                     { this.codigo = codigo; }
    public void setUnidade( int unidade )                   { this.unidade = unidade; }
    public void setQtdEstoque( int qtdEstoque)              { this.qtdEstoque = qtdEstoque; } 
    public void setNome( String nome )                      { this.nome = nome; }
    public void setUltimaVenda( String ultimaVenda)         { this.ultimaVenda = ultimaVenda; }
    public void setPreco( double preco )                    { this.preco = preco; }
}
