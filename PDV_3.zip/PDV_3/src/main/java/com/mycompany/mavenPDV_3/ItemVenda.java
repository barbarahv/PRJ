/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenPDV_3;

/**
 *
 * @author barba
 */
public class ItemVenda {
    private int codigoProduto, qtdVendida, codigoVenda;
    private double preco;
    private String nome;
    
    
    public int getCodigoProduto()                           { return codigoProduto; }
    public double getPreco()                                { return preco; }  
    public int getQtdVendida()                              { return qtdVendida; }
    public int getCodigoVenda()                             { return codigoVenda; }
    public String getNome()                                 { return nome; }
    
    public void setCodigoProduto( int codigo )              { this. codigoProduto = codigo; }
    public void setQtdVendida( int qtdVendida )             { this.qtdVendida = qtdVendida; }
    public void setPreco( double preco )                    { this.preco = preco; }
    public void setCodigoVenda( int codigoVenda )           { this.codigoVenda = codigoVenda; }
    public void setNome( String nome )                      { this.nome = nome; }
}
