/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenPDV_3;

import view.TelaPrincipal;
/**
 *
 * @author barba
 */
public class PDV2 {

    public static void main(String[] args) {
        TelaPrincipal principal = new TelaPrincipal();
        principal.setLocationRelativeTo(null);
        principal.setVisible(true);
    }
}
