/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grade;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author barba
 */
public class ModeloTabelaPessoa extends AbstractTableModel{
    private static final int COLUNA_NOME = 0;
    private static final int COLUNA_TELEFONE = 1;
    private static final int COLUNA_EMAIL = 2;
    private static final int COLUNA_LOGRADOURO = 3;
    private static final int COLUNA_NUMERO = 4;
    private static final int COLUNA_COMPLEMENTO = 5;
    private static final int COLUNA_BAIRRO = 6; 
    private static final int COLUNA_CIDADE = 7;
    private static final int COLUNA_ESTADO = 8;
    private static final int COLUNA_CEP = 9;
    
    
    
    private String[] colunas = new String[] {"Nome", "Telefone", "Email", "Logradouro", "Numero", "Complemento", "Bairro", "Cidade", "Estado", "Cep" };
    private ArrayList<Pessoa> pessoas;

    public ModeloTabelaPessoa(ArrayList<Pessoa>pessoas){
        this.pessoas = new ArrayList<Pessoa>(pessoas);
    }

@Override
public int getColumnCount(){
    return colunas.length;
}

@Override
public int getRowCount(){
    return pessoas.size();
}

@Override
public String getColumnName(int indiceColuna){
    return colunas[indiceColuna];
}

@Override
public boolean isCellEditable(int indiceLinha, int indiceColuna){
    return false;
}

@Override
public Object getValueAt(int indiceLinha, int indiceColuna){
    Pessoa pessoa = pessoas.get(indiceLinha);
    switch(indiceColuna){
        case COLUNA_NOME:
            return pessoa.obterNome();
        case COLUNA_TELEFONE:
            return pessoa.obterTelefone();
         case COLUNA_EMAIL:
            return pessoa.obterEmail();
         case COLUNA_LOGRADOURO:
            return pessoa.obterLogradouro();
        case COLUNA_NUMERO:
            return pessoa.obterNumero();
        case COLUNA_COMPLEMENTO:
            return pessoa.obterComplemento();
        case COLUNA_BAIRRO:
            return pessoa.obterBairro();
        case COLUNA_CIDADE:
            return pessoa.obterCidade();
        case COLUNA_ESTADO:
            return pessoa.obterEstado();
        case COLUNA_CEP:
            return pessoa.obterCep();
        }
        return ""; 
    
    }
    
    //@Override
    public void SetValueAt(Object valor, int indiceLinha, int indiceColuna){
        
        Pessoa pessoa = pessoas.get(indiceLinha);
        switch (indiceColuna){
            case COLUNA_NOME:
                pessoa.atualizarNome(valor.toString());
            case COLUNA_TELEFONE:
                pessoa.atualizarTelefone(valor.toString());
            case COLUNA_EMAIL:
                pessoa.atualizarEmail(valor.toString());
            case COLUNA_LOGRADOURO:
                pessoa.atualizarLogradouro(valor.toString());
            case COLUNA_NUMERO:
                pessoa.atualizarNumero(valor.toString());
            case COLUNA_COMPLEMENTO:
                pessoa.atualizarComplemento(valor.toString());
            case COLUNA_BAIRRO:
                pessoa.atualizarBairro(valor.toString());
            case COLUNA_CIDADE:
                pessoa.atualizarCidade(valor.toString());
            case COLUNA_ESTADO:
                pessoa.atualizarEstado(valor.toString());
            case COLUNA_CEP:
                pessoa.atualizarCep(valor.toString());
                break;
                
        }
    }

    public Pessoa obterPessoa(int indice){
        return pessoas.get(indice);
    }
    
    public void incluirPessoa(Pessoa pessoa){
        pessoas.add(pessoa);
        int ultimo = getRowCount()-1;
        fireTableRowsInserted(ultimo, ultimo);
    }
    
    public void atualizarPessoa(int indice, Pessoa pessoa){
        pessoas.set(indice, pessoa);
        fireTableRowsUpdated(indice, indice);
    }
    
    public void excluirPessoa(int indice){
        pessoas.remove(indice);
        fireTableRowsDeleted(indice, indice);
    }

    private void salvarArquivoObjeto() {
       ObjectOutputStream output = null;
     try{
       try{
        output = new ObjectOutputStream(new FileOutputStream("pessoas.dat"));
        for (int i = 0; i < pessoas.size(); i++) {
        output.writeObject(pessoas.get(i));
     }
     System.out.println("Salvo");
    } finally {
    if (output != null){
    output.close();
   }
  }
} catch(Exception e){
    JOptionPane.showMessageDialog(null, e.getMessage());
  }
}
    
 private void abrirArquivoObjeto(){
    ObjectInputStream input = null;
  try{
    try{
      input = new ObjectInputStream(new FileInputStream("pessoas.dat"));
      Object objeto = null;
      pessoas.clear();
    do {
     objeto = input.readObject();
      pessoas.add((Pessoa)objeto);
   } while (objeto != null); 
   } finally {
   if (input != null){
       input.close();
     }
    }
} catch (EOFException e) { //Não faz nada
} catch (Exception e){
    JOptionPane.showMessageDialog(null, e.getMessage());
   }
  }
}
