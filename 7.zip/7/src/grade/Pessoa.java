/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grade;

import java.io.Serializable;

/**
 *
 * @author barba
 */
public class Pessoa implements Serializable {
    private String nome;
    private String telefone;
    private String email;
    private String logradouro;
    private String numero;
    private String complemento;
    private String bairro;       
    private String cidade;     
    private String estado;
    private String cep;
    
    public String obterNome(){
        return nome;
    }
    
    public String obterTelefone(){
        return telefone;
    }
    
    public String obterEmail(){
        return email;
    }
    
    public String obterLogradouro(){
        return logradouro;
    }
    
    public String obterNumero(){
        return numero;
    }
    
    public String obterComplemento(){
        return complemento;
    }
    
    public String obterBairro(){
        return bairro;
    }
    
    public String obterCidade(){
        return cidade;
    }
    
    public String obterCep(){
        return cep;
    }
    
    public void atualizarNome (String nome){
        this.nome = nome;
    }
    
    public void atualizarTelefone (String telefone){
        this.telefone = telefone;
    }
    
    public void atualizarEmail (String email){
        this.email = email;
    }
   
    public void atualizarLogradouro (String logradouro){
        this.logradouro = logradouro;
    }
    
    public void atualizarNumero (String numero){
        this.numero = numero;
    }
    
    public void atualizarComplemento (String complemento){
        this.complemento = complemento;
    }
     
    public void atualizarBairro (String bairro){
        this.bairro = bairro;
    }
    
    public void atualizarCidade (String cidade){
        this.cidade = cidade;
    }
     public String obterEstado(){
        return estado;
    }
    public void atualizarEstado (String estado){
        this.estado = estado;
    }
    
    public void atualizarCep (String cep){
        this.cep = cep;
    }

    Object get(int i) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    int size() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void clear() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void add(Pessoa pessoa) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

