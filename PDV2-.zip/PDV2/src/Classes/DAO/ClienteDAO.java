/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes.DAO;

import pdv2.Cliente;
import pdv2.ConnectionFactory;
import pdv2.Endereco;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author barba
 */
public class ClienteDAO {
    public void create(Cliente cliente) throws SQLException
    {
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement stmt = null;
        PreparedStatement stmtEndereco = null;
        EnderecoDAO eDAO = new EnderecoDAO();
        
        try 
        {
            con.setAutoCommit(false);
            stmt = con.prepareStatement("INSERT INTO endereco(CEP, rua, numero, complemento, cidade, UF) VALUES (?,?,?,?,?,?)");
            
            stmt.setString(1, cliente.getEndereco().getCEP());
            stmt.setString(2, cliente.getEndereco().getRua());
            stmt.setInt(3, cliente.getEndereco().getNumero());
            stmt.setString(4, cliente.getEndereco().getComplemento());
            stmt.setString(5, cliente.getEndereco().getCidade());
            stmt.setString(6, cliente.getEndereco().getUF());
            
            stmt.executeUpdate();
            
            stmt = con.prepareStatement("INSERT INTO cliente(codigo, telefone, nome, email, CEP) VALUES (?,?,?,?,?)");
            
            stmt.setInt(1, cliente.getCodigo());
            stmt.setInt(2, cliente.getTelefone());
            stmt.setString(3, cliente.getNome());
            stmt.setString(4, cliente.getEmail());
            stmt.setString(5, cliente.getEndereco().getCEP());
            
            stmt.executeUpdate();
            con.commit();
            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
            
        } 
        catch (SQLException ex) 
        {
            JOptionPane.showMessageDialog(null, "Erro ao salvar cliente: " + ex);
            if (con != null){
                try {
                   JOptionPane.showMessageDialog(null, "Transaction is being rolled back.");
                   con.rollback();
                } catch (SQLException excep) {
                    JOptionPane.showMessageDialog(null, excep);
                }
            }
        } 
        finally 
        {
            ConnectionFactory.closeConnection(con, stmt);
        }
    }
    
    public ArrayList<Cliente> read()
    {
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        ArrayList<Cliente> clientes = new ArrayList<>();
        
        try
        {
            stmt = con.prepareStatement("SELECT c.*, e.rua, e.numero, e.complemento, e.cidade, e.UF"
                    + " FROM cliente as c, endereco as e WHERE c.CEP = e.CEP");
            rs = stmt.executeQuery();
            
            while (rs.next())
            {
                Cliente cliente = new Cliente();
                Endereco endereco = new Endereco();
                
                cliente.setCodigo(rs.getInt("codigo"));
                cliente.setTelefone(rs.getInt("telefone"));
                cliente.setNome(rs.getString("nome"));
                cliente.setEmail(rs.getString("email"));
                endereco.setCEP(rs.getString("CEP"));
                endereco.setRua(rs.getString("rua"));
                endereco.setNumero(rs.getInt("numero"));
                endereco.setComplemento(rs.getString("complemento"));
                endereco.setCidade(rs.getString("cidade"));
                endereco.setUF(rs.getString("UF"));
                cliente.setEndereco(endereco);
                
                clientes.add(cliente);
            }
            
        }
        catch (SQLException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        finally
        {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }
        
        return clientes;
    }
    
    public void update(Cliente cliente, String CEP, int codigo)
    {
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement stmt = null; 
        
        try 
        {
            con.setAutoCommit(false);
            stmt = con.prepareStatement("UPDATE endereco SET CEP = ?, rua = ? , "
                    + "numero = ? , complemento = ? , cidade = ? , UF = ? WHERE CEP = ?");
            
            stmt.setString(1, cliente.getEndereco().getCEP());
            stmt.setString(2, cliente.getEndereco().getRua());
            stmt.setInt(3, cliente.getEndereco().getNumero());
            stmt.setString(4, cliente.getEndereco().getComplemento());
            stmt.setString(5, cliente.getEndereco().getCidade());
            stmt.setString(6, cliente.getEndereco().getUF());
            stmt.setString(7, CEP);
            
            stmt.executeUpdate();
            
            stmt = con.prepareStatement("UPDATE cliente SET codigo = ? , telefone = ? , "
                    + "nome = ? , email = ? , CEP = ? WHERE codigo = ?");
            
            stmt.setInt(1, cliente.getCodigo());
            stmt.setInt(2, cliente.getTelefone());
            stmt.setString(3, cliente.getNome());
            stmt.setString(4, cliente.getEmail());
            stmt.setString(5, cliente.getEndereco().getCEP());
            stmt.setInt(6, codigo);
            
            stmt.executeUpdate();           
            con.commit();
            JOptionPane.showMessageDialog(null, "Atualizado com sucesso!");
            
        } 
        catch (SQLException ex) 
        {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar: " + ex);
            if (con != null){
                try {
                   JOptionPane.showMessageDialog(null, "Transaction is being rolled back.");
                   con.rollback();
                } catch (SQLException excep) {
                    JOptionPane.showMessageDialog(null, excep);
                }
            }
        } 
        finally 
        {
            ConnectionFactory.closeConnection(con, stmt);
        }
        
    }
    
    public void delete(Cliente cliente)
    {
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement stmt = null; 
        
        try 
        {
            
            con.setAutoCommit(false);
            stmt = con.prepareStatement("DELETE FROM cliente WHERE codigo = ?");
            
            stmt.setInt(1, cliente.getCodigo());
            
            stmt.executeUpdate();
            
            stmt = con.prepareStatement("DELETE FROM endereco WHERE CEP = ?");
            
            stmt.setString(1, cliente.getEndereco().getCEP());
            
            stmt.executeUpdate();
            con.commit();
            
            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
        } 
        catch (SQLException ex) 
        {
            JOptionPane.showMessageDialog(null, "Erro ao excluir: " + ex);
            if (con != null){
                try {
                   JOptionPane.showMessageDialog(null, "Transaction is being rolled back.");
                   con.rollback();
                } catch (SQLException excep) {
                    JOptionPane.showMessageDialog(null, excep);
                }
            }
        } 
        finally 
        {
            ConnectionFactory.closeConnection(con, stmt);
        }
        
    }
    
    public String getNome(int codigo)
    {
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String nome = null;
        
        try
        {
            stmt = con.prepareStatement("SELECT nome FROM cliente WHERE codigo = ?");
            stmt.setInt(1, codigo);
            rs = stmt.executeQuery();
            
            while (rs.next())
            {
                nome = rs.getString("nome");
            }
            
        }
        catch (SQLException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        finally
        {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }
        
        return nome;
    }
}
