/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pdv2;

/**
 *
 * @author barba
 */
public class Venda {
    private int codigo, formaDePagamento;
    private String data, hora, codigoCliente;
    private double precoTotal;
        
    public int getCodigo()                          { return codigo; }
    public String getData()                         { return data; }
    public String getHora()                         { return hora; }
    public double getPrecoTotal()                   { return precoTotal; }
    public String getCodigoCliente()                { return codigoCliente; }
    public int getFormaPagamento()                  { return formaDePagamento; }
    
    public void setData( String data )              { this.data = data; }
    public void setHora( String hora )              { this.hora = hora; }
    public void setPrecoTotal( double precoTotal )  { this.precoTotal = precoTotal; }
    public void setCodigo(int codigo)               {this.codigo = codigo;}
    public void setCodigoCliente(String codigoCliente) { this.codigoCliente = codigoCliente; }
    public void setFormaPagamento( int formaDePagamento ) { this.formaDePagamento = formaDePagamento; }
}
