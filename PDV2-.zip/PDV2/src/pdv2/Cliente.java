/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pdv2;

/**
 *
 * @author barba
 */
public class Cliente {
    private int codigo, telefone;
    private String nome, email;
    private Endereco endereco = new Endereco();
    
    public int getCodigo()                          { return codigo; }
    public int getTelefone()                        { return telefone; }
    public String getNome()                         { return nome; }
    public String getEmail()                        { return email; }
    public Endereco getEndereco()                   { return endereco;   } 
    
    public void setCodigo( int codigo )             { this.codigo = codigo; }
    public void setTelefone( int telefone )         { this.telefone = telefone; }
    public void setNome( String nome )              { this.nome = nome; }
    public void setEmail(String email )             { this.email = email; }
    public void setEndereco(Endereco endereco)        { this.endereco = endereco; }
}
