/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pdv2;

/**
 *
 * @author barba
 */
public class Endereco {
    private String rua, complemento, cidade, UF, CEP;
    private int numero;
    
    public String getRua()                              { return rua; }
    public String getComplemento()                      { return complemento; }
    public String getCidade()                           { return cidade; }
    public String getUF()                               { return UF; }
    public String getCEP()                              { return CEP; }
    public int getNumero()                              { return numero; }
    
    public void setRua( String rua )                    { this.rua = rua; }
    public void setComplemento ( String complemento )   { this.complemento = complemento; }
    public void setCidade( String cidade )              { this.cidade = cidade; }
    public void setUF( String UF )                      { this.UF = UF; }
    public void setCEP( String CEP )                    { this.CEP = CEP; }
    public void setNumero(int numero)                   { this.numero = numero; }
}
